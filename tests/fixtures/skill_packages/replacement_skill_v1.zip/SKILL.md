---
schema_version: 1
skill_id: replace-test
name: Replace Test v1
version: 1.0.0
description: A test skill for unit testing
skill_type: instruction
capabilities:
  - read
entrypoints:
  run: run.py
---

# Test Skill

This is a test skill for unit testing.
